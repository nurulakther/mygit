#!/usr/bin/env bash
set -o pipefail

GLOBAL_PKGS="avahi nss-mdns" # MDNS/zeroconf
yum install epel-release  -q -y --nogpgcheck

if [[ $HOSTNAME = "app" ]]; then
  # install python
  yum install python3-dev python3-pip python36-virtualenv postgresql-devel gcc ${GLOBAL_PKGS} -q -y --nogpgcheck
  # Setup up python virtualenv
  su - vagrant -c "( virtualenv-3 -p python3 venv && source venv/bin/activate && pip install flask psycopg2 )"
elif [[ $HOSTNAME = "db" ]]; then
  # install database
  yum install postgresql-server ${GLOBAL_PKGS} -q -y --nogpgcheck
  postgresql-setup initdb
  echo "Configuring for app..."
  echo "listen_addresses = '*'" >> /var/lib/pgsql/data/postgresql.conf
  echo "host    all             app             172.28.128.0/24            ident" >> /var/lib/pgsql/data/pg_hba.conf
  systemctl start postgresql
  systemctl enable postgresql
  echo "CREATE USER app with password 'app';" | su - postgres -c psql || true
  su - postgres -c "createdb -O app appdb" || true
  echo "CREATE TABLE IF NOT EXISTS apptab (\
    message varchar(45) NOT NULL\
    )" | su - postgres -c "psql -d appdb" || true
  echo "GRANT ALL PRIVILEGES ON TABLE apptab TO app; " |  su - postgres -c "psql -d appdb"
  echo "INSERT INTO apptab (message) VALUES ('Hello, World')" | su - postgres -c "psql -d appdb" || true
elif [[ $HOSTNAME = "proxy" ]]; then
  # install proxy
  yum install python ${GLOBAL_PKGS} -q -y --nogpgcheck
else
  false
fi
# MDNS so VMs can talk to each other by name
systemctl start avahi-daemon
systemctl enable avahi-daemon
