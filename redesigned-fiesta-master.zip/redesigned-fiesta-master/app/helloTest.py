# helloTest.py
# at the end point / call method hello which returns "hello world"
from flask import Flask
from flask import request

import psycopg2


def content():
    con = psycopg2.connect(database="appdb", user="app", password="app", host="db.local", port="5432")
    cur = con.cursor()
    cur.execute("select * from apptab" )
    return cur.fetchone()[0]
    con.close()

app = Flask(__name__)

@app.route("/")
def hello():
  return (content())

if __name__ == '__main__':
  app.run(host='0.0.0.0')
