#!/bin/env bash

echo "Starting app..."
pushd $HOME
nohup python app/helloTest.py >> nohup.out 2>&1  &
sleep 1
tail -6 nohup.out
popd
