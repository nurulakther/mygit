# jubilant-guacamole
## Description

A tech test to demonstrate your skills

We would like to understand your ability to understand a system, troubleshoot
issues and see how you work.

You will demonstrate your ability to:
- understand a complex system
- troubleshoot issues
- produce a working system *perfect is the enemy of the good*
- work in a collaborative codebase
- suggest improvements to systems
- implement DevOps practices and principles
- manage your time and priorities

We would like to follow your process while working on this:
Please use frequent and small commits. Explain the changes you have made and
why you chose to make those changes.

We do not expect or want you to spend more than an hour on this test excluding
setup time.

Please list what you think is left to do as an issue in github. A simple list in
one issue is great.

The app should load through a proxy at http://proxy.local/

## Prerequisites:

- An hour of your time
- Internet access
- A github account
- Virtualbox on your system
- Vagrant installed on your system
- Ansible on your system
- You can pre-fetch the "centos/7" box to save some time:
`vagrant box add  "centos/7" --provider virtualbox`

## The task

We have a webapp that used to work in a virtualbox vagrant environment.

But the webapp is not working now for some reason...

*You will identify and fix the issues with the app.*

***There are 3 VMs that each play a role.

***Doing a `vagrant up` *will* start these up. You can get on a shell to them 
with `vagrant ssh <name>`. The project uses *mDNS*, so you can acess their services 
by `<name>.local` on other ports.

If you have issues with the above, :stop:, there is something not right in your setup
and fixing that is not part of this assessment.

* Make small changes, frequent commits with comments briefly explaining the reason
for your fixes.

* Once you are done, or an hour is up make your final commit and submit a Pull
Request.

* Include a screenshot of the browser in the Pull Request.

## Tips

* Make small sets of related changes and commit them often.

* Please don't check in your vagrant machines. Use the git best practice to achieve
this.

* Explain your choices in your small commits. For example, if you choose to disable
any security settings, explain why.

* If there are better ways to do things that follow best or common practices, please
add those to the issue of improvements. You are free to implement them if you
have time, but you don't need to.

* Take notes on how the system works. We may ask you about it later.

* Relax. Please don't spend much more than an hour on this. We will assess your
troubleshooting skills more than specific knowledge of the tools in this test.
